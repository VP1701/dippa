"""Visualize the CBF-from-OGM simulation."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from cbf_from_ogm import run, extract_cbf_constraints, cbf_qp, OccupancyGrid

out = run()
g, gt, tr = out['grid'], out['gt_occ'], out['traj']
refs, exes, interv = out['refs'], out['exes'], out['interventions']
r_safe, dt = out['r_safe'], out['dt']
W, Hh = g.nx * g.res, g.ny * g.res
extent = [0, W, 0, Hh]

fig = plt.figure(figsize=(13, 7.5))
gs = fig.add_gridspec(2, 2, height_ratios=[1.25, 1], width_ratios=[1.6, 1],
                      hspace=0.32, wspace=0.22)

# ---- (A) top: full run over the discovered occupancy grid -----------------
axA = fig.add_subplot(gs[0, :])
axA.imshow(g.prob(), origin='lower', extent=extent, cmap='Greys',
           vmin=0, vmax=1, alpha=0.9)
# ground-truth obstacle outlines
axA.contour(np.linspace(0, W, g.nx), np.linspace(0, Hh, g.ny),
            gt.astype(float), levels=[0.5], colors='tab:red', linewidths=1.2,
            alpha=0.7)
# trajectory, coloured by whether the CBF intervened
seg = np.array(tr)
free = ~interv
axA.plot(seg[free, 0], seg[free, 1], '.', ms=3, color='tab:blue', label='filter passive (user input applied as-is)')
axA.plot(seg[interv, 0], seg[interv, 1], '.', ms=4, color='tab:orange', label='CBF intervening')
axA.plot(seg[0, 0], seg[0, 1], 'go', ms=9, label='start')
axA.plot(out['goal'][0], out['goal'][1], 'm*', ms=15, label='goal')
axA.set_title("Robot navigating with CBF constraints built live from the occupancy grid "
              "(grey = discovered map, red = true obstacles)", fontsize=10)
axA.set_xlabel("x [m]"); axA.set_ylabel("y [m]")
axA.set_aspect('equal'); axA.legend(loc='lower right', fontsize=8, framealpha=0.9)

# ---- (B) bottom-left: close-up of the live constraints at one instant -----
# pick the most constrained intervening step for a rich snapshot
k = int(np.argmax([n if interv[i] else -1 for i, n in enumerate(out['n_cons'])]))
p_k = tr[k]
cons_k = extract_cbf_constraints(g, p_k, r_safe, 1.2)
u_ref_k, u_safe_k = refs[k], exes[k]

axB = fig.add_subplot(gs[1, 0])
axB.imshow(g.prob(), origin='lower', extent=extent, cmap='Greys', vmin=0, vmax=1)
axB.plot(p_k[0], p_k[1], 'ko', ms=8, zorder=5)
axB.add_patch(Circle(p_k, r_safe, fill=False, ec='k', ls=':', lw=1))
for c in cons_k:
    cpt = c['c']
    axB.plot(cpt[0], cpt[1], 'rx', ms=8, mew=2)            # obstacle point c
    axB.plot([p_k[0], cpt[0]], [p_k[1], cpt[1]], 'r-', lw=0.8, alpha=0.5)
    # the constraint half-space boundary: grad_h . (q - p) = 0 through p, normal grad_h
    n = c['grad_h']; tang = np.array([-n[1], n[0]])
    line = np.array([p_k - 0.5 * tang, p_k + 0.5 * tang])
    axB.plot(line[:, 0], line[:, 1], 'r-', lw=1.5, alpha=0.8)
# velocity vectors
sc = 0.5
axB.arrow(*p_k, *(sc * u_ref_k), color='tab:green', width=0.012, head_width=0.06,
          length_includes_head=True, zorder=6)
axB.arrow(*p_k, *(sc * u_safe_k), color='tab:orange', width=0.012, head_width=0.06,
          length_includes_head=True, zorder=6)
axB.text(0.02, 0.97, "green = user reference velocity\norange = CBF-filtered velocity\n"
                     "red x = obstacle point c (per constraint)\nred line = constraint boundary",
         transform=axB.transAxes, va='top', fontsize=7.5,
         bbox=dict(fc='white', alpha=0.85, ec='none'))
axB.set_xlim(p_k[0] - 1.3, p_k[0] + 1.3); axB.set_ylim(p_k[1] - 1.3, p_k[1] + 1.3)
axB.set_aspect('equal')
axB.set_title(f"Constraints at t={k*dt:.1f}s  ({len(cons_k)} active)", fontsize=9)
axB.set_xlabel("x [m]"); axB.set_ylabel("y [m]")

# ---- (C) bottom-right: intervention magnitude + #constraints over time ----
axC = fig.add_subplot(gs[1, 1])
tvec = np.arange(len(tr)) * dt
dev = np.linalg.norm(exes - refs, axis=1)
axC.plot(tvec, dev, color='tab:orange', lw=1.3, label='|u_safe - u_ref|  (intervention)')
axC.set_xlabel("time [s]"); axC.set_ylabel("intervention [m/s]")
axC.set_ylim(bottom=0)
ax2 = axC.twinx()
ax2.plot(tvec, out['n_cons'], color='tab:gray', lw=1.0, alpha=0.6, label='# active constraints')
ax2.set_ylabel("# constraints")
axC.set_title("Minimal intervention: filter only acts near obstacles", fontsize=9)
l1, lab1 = axC.get_legend_handles_labels(); l2, lab2 = ax2.get_legend_handles_labels()
axC.legend(l1 + l2, lab1 + lab2, fontsize=7, loc='upper center')

fig.suptitle("CBF safety filter with constraints extracted online from a LIDAR occupancy grid",
             fontsize=12, y=0.98)
fig.savefig("/home/claude/cbf_ogm_demo.png", dpi=130, bbox_inches='tight')
print("saved figure; intervention steps:", int(interv.sum()), "/", len(tr))
