"""
CBF constraints from a real-time Occupancy Grid Map (OGM)
=========================================================

Scenario: a velocity-controlled mobile robot (single integrator, p_dot = u)
drives toward a goal. It carries a LIDAR. As it moves, the LIDAR updates an
occupancy grid. Every control cycle we EXTRACT CBF CONSTRAINTS from the current
grid around the robot's position, then solve a minimal-intervention CBF-QP that
keeps the user's reference velocity safe.

The point of interest is `extract_cbf_constraints` -- that is where the grid is
turned into the half-space constraints the QP needs, online, with no offline
precomputation. New obstacles that the grid only reveals up close simply become
new constraints on the next cycle.

Model (matches the relative-degree-1 case discussed):
    state    p   = [x, y]            (position)
    control  u   = [vx, vy]          (commanded velocity = controller OUTPUT)
    dynamics p_dot = u               (single integrator; low-level loop tracks u)

For each nearby obstacle point c the safety constraint is a distance barrier
    h(p)        = ||p - c|| - r_safe                  (h >= 0 is safe)
    grad h(p)   = (p - c) / ||p - c||
CBF condition (continuous, linear class-K with gain gamma):
    grad_h . u  >= -gamma * h
Rearranged into the standard QP inequality form  a^T u <= b :
    a = -grad_h ,   b = gamma * h
"""

import numpy as np
from scipy import ndimage
from scipy.optimize import minimize, NonlinearConstraint


# --------------------------------------------------------------------------- #
# 1. Occupancy grid with a log-odds update from a simulated LIDAR             #
# --------------------------------------------------------------------------- #
class OccupancyGrid:
    def __init__(self, width, height, res, origin=(0.0, 0.0)):
        self.res = res                       # metres per cell
        self.origin = np.array(origin)       # world coord of cell (0,0) corner
        self.nx = int(round(width / res))
        self.ny = int(round(height / res))
        self.logodds = np.zeros((self.ny, self.nx))   # 0 == unknown (p = 0.5)
        self.L_OCC, self.L_FREE = 0.85, -0.40         # per-hit log-odds updates
        self.L_CLAMP = 6.0

    def world_to_cell(self, p):
        c = ((np.asarray(p) - self.origin) / self.res).astype(int)
        return c[0], c[1]                    # (ix, iy)

    def cell_to_world(self, ix, iy):
        return self.origin + (np.array([ix, iy]) + 0.5) * self.res

    def prob(self):
        return 1.0 - 1.0 / (1.0 + np.exp(self.logodds))

    def integrate_scan(self, robot_p, ground_truth_occ, sensor_range, n_rays=120):
        """Cast rays in the ground-truth map and fold the hits into log-odds."""
        for ang in np.linspace(0, 2 * np.pi, n_rays, endpoint=False):
            d = self._raycast(robot_p, ang, ground_truth_occ, sensor_range)
            hit = d < sensor_range
            steps = int(d / (self.res * 0.5))
            for s in range(steps):                       # free space along ray
                fp = robot_p + (s * self.res * 0.5) * np.array([np.cos(ang), np.sin(ang)])
                ix, iy = self.world_to_cell(fp)
                if 0 <= ix < self.nx and 0 <= iy < self.ny:
                    self.logodds[iy, ix] = np.clip(self.logodds[iy, ix] + self.L_FREE,
                                                   -self.L_CLAMP, self.L_CLAMP)
            if hit:                                       # the obstacle cell itself
                hp = robot_p + d * np.array([np.cos(ang), np.sin(ang)])
                ix, iy = self.world_to_cell(hp)
                if 0 <= ix < self.nx and 0 <= iy < self.ny:
                    self.logodds[iy, ix] = np.clip(self.logodds[iy, ix] + self.L_OCC,
                                                   -self.L_CLAMP, self.L_CLAMP)

    def _raycast(self, p, ang, gt_occ, max_range):
        step = self.res * 0.5
        dirn = np.array([np.cos(ang), np.sin(ang)])
        n = int(max_range / step)
        for s in range(1, n + 1):
            q = p + s * step * dirn
            ix, iy = self.world_to_cell(q)
            if not (0 <= ix < self.nx and 0 <= iy < self.ny):
                return s * step
            if gt_occ[iy, ix]:
                return s * step
        return max_range


# --------------------------------------------------------------------------- #
# 2. >>> THE PART THAT MATTERS <<<                                            #
#    Turn the live grid into CBF half-space constraints around the robot      #
# --------------------------------------------------------------------------- #
def extract_cbf_constraints(grid, robot_p, r_safe, influence_R,
                            occ_thresh=0.6, max_constraints=8):
    """
    Returns a list of dicts, one CBF constraint per nearby obstacle cluster:
        {'a': a, 'b': b, 'h': h, 'c': c}
    such that the safety requirement is  a^T u <= b .

    Pipeline (this is the OGM -> constraints bridge):
      1. threshold the probability grid to a binary 'occupied' mask
      2. keep only occupied cells within `influence_R` of the robot
      3. label them into connected obstacle clusters (so one obstacle = one
         persistent constraint; we never collapse to a single 'nearest point',
         which is what causes the wall-to-wall chattering)
      4. for each cluster take its closest cell to the robot -> obstacle point c
      5. build the distance-barrier CBF constraint at c
    """
    prob = grid.prob()
    occupied = prob > occ_thresh

    # --- restrict to a local window around the robot (cheap, and all you can act on)
    cix, ciy = grid.world_to_cell(robot_p)
    rad_cells = int(np.ceil(influence_R / grid.res))
    y0, y1 = max(0, ciy - rad_cells), min(grid.ny, ciy + rad_cells + 1)
    x0, x1 = max(0, cix - rad_cells), min(grid.nx, cix + rad_cells + 1)
    local = occupied[y0:y1, x0:x1]
    if not local.any():
        return []

    # --- cluster the local occupied cells into distinct obstacles
    labels, n_lab = ndimage.label(local)

    constraints = []
    for lab in range(1, n_lab + 1):
        ys, xs = np.where(labels == lab)
        # world coordinates of every cell in this cluster
        wpts = np.stack([grid.origin[0] + (xs + x0 + 0.5) * grid.res,
                         grid.origin[1] + (ys + y0 + 0.5) * grid.res], axis=1)
        # closest point of this obstacle to the robot
        dists = np.linalg.norm(wpts - robot_p, axis=1)
        c = wpts[np.argmin(dists)]
        dmin = dists.min()
        if dmin > influence_R:
            continue

        # ---- build the CBF constraint for this obstacle point ----
        diff = robot_p - c
        dist = np.linalg.norm(diff)
        if dist < 1e-6:
            continue
        grad_h = diff / dist                    # points away from obstacle
        h = dist - r_safe                        # barrier value (>=0 is safe)
        a = -grad_h                              # a^T u <= b  encodes  grad_h.u >= -gamma*h
        constraints.append({'a': a, 'b': None, 'h': h, 'c': c, 'grad_h': grad_h})

    # keep only the most binding ones (smallest h) for a bounded-size QP
    constraints.sort(key=lambda k: k['h'])
    return constraints[:max_constraints]


# --------------------------------------------------------------------------- #
# 3. The minimal-intervention CBF-QP safety filter                           #
# --------------------------------------------------------------------------- #
def cbf_qp(u_ref, constraints, gamma, v_max):
    """
    min_u  ||u - u_ref||^2
    s.t.   grad_h_i . u >= -gamma * h_i     (each obstacle)
           ||u||_inf <= v_max               (actuator limits)
    Small 2-D QP; solved here with SLSQP (swap in OSQP/qpsolvers in production).
    """
    u_ref = np.asarray(u_ref, float)

    def cost(u):       return np.sum((u - u_ref) ** 2)
    def cost_grad(u):  return 2.0 * (u - u_ref)

    cons = []
    for k in constraints:
        gh, h = k['grad_h'], k['h']
        # grad_h . u + gamma*h >= 0
        cons.append({'type': 'ineq',
                     'fun': (lambda u, gh=gh, h=h: gh @ u + gamma * h),
                     'jac': (lambda u, gh=gh: gh)})

    bounds = [(-v_max, v_max), (-v_max, v_max)]
    res = minimize(cost, u_ref, jac=cost_grad, bounds=bounds,
                   constraints=cons, method='SLSQP',
                   options={'maxiter': 50, 'ftol': 1e-8})
    u_safe = res.x if res.success else u_ref
    intervened = np.linalg.norm(u_safe - u_ref) > 1e-3
    return u_safe, intervened


# --------------------------------------------------------------------------- #
# 4. Demo world + simulation loop                                            #
# --------------------------------------------------------------------------- #
def build_ground_truth(grid):
    """Hallway (two walls) + a central block + a 'surprise' block behind a corner."""
    occ = np.zeros((grid.ny, grid.nx), dtype=bool)

    def fill_rect(x0, y0, x1, y1):
        i0, j0 = grid.world_to_cell((x0, y0))
        i1, j1 = grid.world_to_cell((x1, y1))
        occ[max(0, j0):min(grid.ny, j1), max(0, i0):min(grid.nx, i1)] = True

    W, H = grid.nx * grid.res, grid.ny * grid.res
    t = 0.3
    fill_rect(0, 0, W, t)              # bottom wall
    fill_rect(0, H - t, W, H)          # top wall
    fill_rect(3.0, 0.3, 3.8, 2.3)      # block intruding from bottom -> pass above
    fill_rect(6.0, H - 2.3, 6.8, H - 0.3)  # block intruding from top -> pass below
    return occ


def run():
    grid = OccupancyGrid(width=10.0, height=4.0, res=0.05, origin=(0.0, 0.0))
    gt_occ = build_ground_truth(grid)

    # robot / controller parameters
    p = np.array([0.6, 2.0])           # start
    dt = 0.05
    v_nom = 1.0                         # speed the 'user' commands toward the waypoint
    v_max = 1.5
    r_safe = 0.25                       # robot radius + disturbance margin
    gamma = 2.0
    influence_R = 1.2
    sensor_range = 2.5

    # The 'user' is not perfect: these waypoints round the blocks but cut the
    # corners (slightly unsafe). The CBF filter's job is to keep that rough
    # human intent collision-free with minimal interference.
    waypoints = [np.array(w) for w in
                 [(3.1, 2.75), (5.0, 2.0), (6.7, 1.25), (9.4, 2.0)]]
    goal = waypoints[-1]
    wp_idx = 0

    traj, refs, exes, interventions, n_cons = [], [], [], [], []
    snapshots = {}                       # grid prob snapshots for plotting

    for step in range(600):
        # ---- perception: update the OGM from the robot's current position ----
        grid.integrate_scan(p, gt_occ, sensor_range)

        # ---- user reference: head toward the current waypoint ----
        if wp_idx < len(waypoints) - 1 and np.linalg.norm(waypoints[wp_idx] - p) < 0.35:
            wp_idx += 1
        target = waypoints[wp_idx]
        to_t = target - p
        u_ref = v_nom * to_t / (np.linalg.norm(to_t) + 1e-9)

        # ---- creation of CBF constraints from the live grid ----
        constraints = extract_cbf_constraints(grid, p, r_safe, influence_R)

        # ---- minimal-intervention safety filter ----
        u_safe, intervened = cbf_qp(u_ref, constraints, gamma, v_max)

        # ---- integrate (low-level loop assumed to track u_safe) ----
        p = p + dt * u_safe

        traj.append(p.copy()); refs.append(u_ref.copy()); exes.append(u_safe.copy())
        interventions.append(intervened); n_cons.append(len(constraints))

        if step in (60, 150, 320):
            snapshots[step] = grid.prob().copy()

        if np.linalg.norm(goal - p) < 0.2:
            print(f"goal reached at step {step}, t={step*dt:.1f}s")
            break

    return dict(grid=grid, gt_occ=gt_occ, traj=np.array(traj),
                refs=np.array(refs), exes=np.array(exes),
                interventions=np.array(interventions), n_cons=np.array(n_cons),
                snapshots=snapshots, r_safe=r_safe, goal=goal, dt=dt)


if __name__ == "__main__":
    out = run()
    # quick sanity report
    coll = out['gt_occ']
    g = out['grid']
    hit = 0
    for p in out['traj']:
        ix, iy = g.world_to_cell(p)
        if coll[iy, ix]:
            hit += 1
    print(f"steps: {len(out['traj'])}, interventions: {out['interventions'].sum()}, "
          f"collisions: {hit}, max active constraints: {out['n_cons'].max()}")
